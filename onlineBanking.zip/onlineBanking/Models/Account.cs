﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Account
{
    public int AccountId { get; set; }

    public string? AccountType { get; set; }

    public decimal? Balance { get; set; }

    public string? CreatedAt { get; set; }
}
