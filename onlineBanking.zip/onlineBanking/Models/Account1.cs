﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Account1
{
    public int? RegisteredId { get; set; }

    public int? AccountId { get; set; }

    public virtual Account? Account { get; set; }

    public virtual Registered? Registered { get; set; }
}
