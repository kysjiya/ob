﻿using System;
using System.Collections.Generic;

namespace onlineBanking;

public partial class TransactionForeign
{
    public int? RegisteredId { get; set; }

    public int? TransacId { get; set; }

    public virtual Registered? Registered { get; set; }

    public virtual Transaction? Transac { get; set; }
}
