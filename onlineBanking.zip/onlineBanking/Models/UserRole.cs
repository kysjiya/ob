﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class UserRole
{
    public int UserRoleId { get; set; }

    public string? UserRole1 { get; set; }
}
