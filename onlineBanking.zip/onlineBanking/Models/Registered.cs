﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Registered
{
    public int RegisteredId { get; set; }

    public string? AtmPin { get; set; }

    public string? DebitcardNumber { get; set; }

    public string? Email { get; set; }

    public string? Username { get; set; }

    public string? UserPass { get; set; }
}
