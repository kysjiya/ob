﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using onlineBanking;
using onlineBanking.Models;
using Microsoft.AspNetCore.Authorization;
using onlineBanking.Data;
namespace onlineBanking.Controllers;

public class HomeController : Controller
{
  private readonly OnlinebankingContext _context;

    public HomeController(OnlinebankingContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

      public IActionResult AccountLists()
    {
        return View();
    }

      public IActionResult upgrade()
    {
        return View();
    }

  public IActionResult transaction()
    {
        return View();
    }

      public IActionResult maps()
    {
        return View();
    }

  public IActionResult statements()
    {
        return View();
    }

 public IActionResult request_form()
    {
        return View();
    }

      public IActionResult profile()
    {
        return View();
    }
    
 [HttpGet]
      public IActionResult register()
    {
        return View();
    }

 [HttpPost]
      public IActionResult register(Registered registered, User user)
    {
       

      _context.Registereds.Add(registered);
                 _context.SaveChangesAsync();

                // Create User entity linked to the Registered entity
                // var user = new User
                // {
                //     RegisteredId = registered.RegisteredId,
                //     UserRoleId = 1 // Assign a default or specified role ID
                // };

                // Add User entity to the context
                _context.Users.Add(user);
                 _context.SaveChangesAsync();
        return View();
    }

        public IActionResult Login()
        {
            return View();
        }

      public IActionResult tables()
    {
        return View();
    }
   
}
