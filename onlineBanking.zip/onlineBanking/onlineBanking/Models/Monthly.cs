﻿using System;
using System.Collections.Generic;

namespace onlineBanking;

public partial class Monthly
{
    public int? RegisteredId { get; set; }

    public int? MonthId { get; set; }

    public virtual MonthlyStatement? Month { get; set; }

    public virtual Registered? Registered { get; set; }
}
