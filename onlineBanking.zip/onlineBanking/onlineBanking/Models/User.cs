﻿using System;
using System.Collections.Generic;

namespace onlineBanking;

public partial class User
{
    public int? RegisteredId { get; set; }

    public int? UserRoleId { get; set; }

    public virtual Registered? Registered { get; set; }

    public virtual UserRole? UserRole { get; set; }
}
