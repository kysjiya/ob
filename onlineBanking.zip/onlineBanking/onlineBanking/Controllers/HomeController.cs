﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using onlineBanking.Models;
using Microsoft.AspNetCore.Authorization;
namespace onlineBanking.Controllers;

public class HomeController : Controller
{
  

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult login()
    {
        return View();
    }

      public IActionResult AccountLists()
    {
        return View();
    }

      public IActionResult upgrade()
    {
        return View();
    }

  public IActionResult transaction()
    {
        return View();
    }

      public IActionResult maps()
    {
        return View();
    }

      public IActionResult profile()
    {
        return View();
    }

      public IActionResult register()
    {
        return View();
    }
 [HttpPost]
       

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }


      public IActionResult tables()
    {
        return View();
    }

   
}
