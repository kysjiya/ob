// using Microsoft.AspNetCore.Authentication.Cookies;
// using Microsoft.AspNetCore.Authentication;
// using System.Security.Claims;

// using Microsoft.AspNetCore.Mvc;

// namespace onlineBanking.Controllers
// {
//     public class AuthController : Controller
//     {

//         private readonly OnlineBankingContext db;

//         public AuthController(OnlineBankingContext context)
//         {
//             db = context;
//         }
//         public IActionResult login()
//         {
//             return View();
//         }

//         [HttpPost]
//         public IActionResult login(User user)
//         {

            
//             ClaimsIdentity identity = null;
//             bool isAuthenticated = false;
//             int roleLogin = 0;
//             string cnt = "";
//             var fetchingUser = db.Users.FirstOrDefault(m => m.Email == user.Email && m.PasswordHash==user.PasswordHash) ;
//             if (fetchingUser !=null)
//             {
//                 if (fetchingUser.RoleId == 1)
//                 {
//                     HttpContext.Session.SetString("username", fetchingUser.FullName);
//                     //Create the identity for the user
//                     identity = new ClaimsIdentity(new[] {
//                     new Claim(ClaimTypes.Name, fetchingUser.FullName),
//                     new Claim(ClaimTypes.Role, "Admin")
//                 }, CookieAuthenticationDefaults.AuthenticationScheme);
//                     cnt = "Admin";
//                     isAuthenticated = true;
//                     roleLogin = 1;
//                 }

//                 else if (fetchingUser.RoleId == 2)
//                 {
//                     //Create the identity for the user
//                     identity = new ClaimsIdentity(new[] {
//                     new Claim(ClaimTypes.Name, fetchingUser.FullName),
//                     new Claim(ClaimTypes.Role, "User")
//                 }, CookieAuthenticationDefaults.AuthenticationScheme);

//                     isAuthenticated = true;
//                     roleLogin = 2;
//                     cnt = "Home";
//                 }
//                 else if ( fetchingUser.RoleId == 3)
//                 {
//                     //Create the identity for the user
//                     identity = new ClaimsIdentity(new[] {
//                     new Claim(ClaimTypes.Name, fetchingUser.FullName),
//                     new Claim(ClaimTypes.Role, "Caterer")
//                 }, CookieAuthenticationDefaults.AuthenticationScheme);

//                     isAuthenticated = true;
//                     roleLogin = 3;
//                     cnt = "Caterers";
//                 }

//                 if (isAuthenticated) //&& roleLogin ==1)
//                 {
//                     var principal = new ClaimsPrincipal(identity);

//                     var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);



//                     return RedirectToAction("Index", "Home");
//                     //return RedirectToAction("Index", cnt);
//                 }
//                 //else   if (isAuthenticated && roleLogin == 2)
//                 //   {
//                 //       var principal = new ClaimsPrincipal(identity);

//                 //       var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);






//                 //       return RedirectToAction("Index", "Home");
//                 //   }
//                 //   else if (isAuthenticated && roleLogin == 3)
//                 //   {
//                 //       var principal = new ClaimsPrincipal(identity);

//                 //       var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);






//                 //       return RedirectToAction("Index", "Caterer");
//                 //   }
//                 else
//                 {

//                     return View();
//                 }
//             }
//             else
//             {
//                 return View();
//             }
         
//         }




//         public IActionResult Logout()
//         {
//             var login = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
//             return RedirectToAction("Login");
//         }
//     }
// }