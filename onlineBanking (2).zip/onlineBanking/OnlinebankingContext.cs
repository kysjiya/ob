﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace onlineBanking;

public partial class OnlinebankingContext : DbContext
{
    public OnlinebankingContext()
    {
    }

    public OnlinebankingContext(DbContextOptions<OnlinebankingContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Account> Accounts { get; set; }

    public virtual DbSet<Account1> Accounts1 { get; set; }

    public virtual DbSet<AccountNumber> AccountNumbers { get; set; }

    public virtual DbSet<Annual> Annuals { get; set; }

    public virtual DbSet<AnnualStatement> AnnualStatements { get; set; }

    public virtual DbSet<Monthly> Monthlies { get; set; }

    public virtual DbSet<MonthlyStatement> MonthlyStatements { get; set; }

    public virtual DbSet<Registered> Registereds { get; set; }

    public virtual DbSet<Request> Requests { get; set; }

    public virtual DbSet<Request1> Requests1 { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    public virtual DbSet<TransactionForeign> TransactionForeigns { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<UserRole> UserRoles { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.;Database=onlinebanking;User Id=sa;Password=aptech;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Account>(entity =>
        {
            entity.HasKey(e => e.AccountId).HasName("PK__Account__46A222CD2FFCBCAF");

            entity.ToTable("Account");

            entity.Property(e => e.AccountId).HasColumnName("account_id");
            entity.Property(e => e.AccountType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("account_type");
            entity.Property(e => e.Balance)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("balance");
            entity.Property(e => e.CreatedAt)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("created_at");
        });

        modelBuilder.Entity<Account1>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Accounts");

            entity.Property(e => e.AccountId).HasColumnName("account_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Account).WithMany()
                .HasForeignKey(d => d.AccountId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Accounts__accoun__2A4B4B5E");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Accounts__regist__29572725");
        });

        modelBuilder.Entity<AccountNumber>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("account_number");

            entity.HasIndex(e => e.AccountNumber1, "UQ__account___AF91A6ADC384383C").IsUnique();

            entity.Property(e => e.AccountNumber1).HasColumnName("account_number");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__account_n__regis__412EB0B6");
        });

        modelBuilder.Entity<Annual>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("annual");

            entity.Property(e => e.AnnualId).HasColumnName("annual_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.AnnualNavigation).WithMany()
                .HasForeignKey(d => d.AnnualId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__annual__annual_i__3E52440B");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__annual__register__3D5E1FD2");
        });

        modelBuilder.Entity<AnnualStatement>(entity =>
        {
            entity.HasKey(e => e.StatementId).HasName("PK__Annual_S__7BE2B338A49DB4C1");

            entity.ToTable("Annual_Statements");

            entity.Property(e => e.StatementId).HasColumnName("statement_id");
            entity.Property(e => e.StatementDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("date")
                .HasColumnName("statement_date");
            entity.Property(e => e.StatementDetails)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("statement_details");
        });

        modelBuilder.Entity<Monthly>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("monthly");

            entity.Property(e => e.MonthId).HasColumnName("month_id");
            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");

            entity.HasOne(d => d.Month).WithMany()
                .HasForeignKey(d => d.MonthId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__monthly__month_i__3B75D760");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__monthly__registe__3A81B327");
        });

        modelBuilder.Entity<MonthlyStatement>(entity =>
        {
            entity.HasKey(e => e.MonthStatementId).HasName("PK__Monthly___AF19A0BC21315D87");

            entity.ToTable("Monthly_Statements");

            entity.Property(e => e.MonthStatementId).HasColumnName("month_statement_id");
            entity.Property(e => e.MonthStatementDate)
                .HasColumnType("date")
                .HasColumnName("month_statement_date");
            entity.Property(e => e.MonthStatementDetails)
                .HasMaxLength(255)
                .IsUnicode(false)
                .HasColumnName("month_statement_details");
        });

        modelBuilder.Entity<Registered>(entity =>
        {
            entity.HasKey(e => e.RegisteredId).HasName("PK__Register__605EADF8E8B33D05");

            entity.ToTable("Registered");

            entity.HasIndex(e => e.DebitcardNumber, "UQ__Register__852CA7F196F42D87").IsUnique();

            entity.HasIndex(e => e.Username, "UQ__Register__F3DBC572F00AAA3E").IsUnique();

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.AtmPin)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("ATM_pin");
            entity.Property(e => e.DebitcardNumber)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("debitcard_number");
            entity.Property(e => e.Email)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.UserPass)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("user_pass");
            entity.Property(e => e.Username)
                .HasMaxLength(200)
                .IsUnicode(false)
                .HasColumnName("username");
        });

        modelBuilder.Entity<Request>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("request");

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.ReqId).HasColumnName("req_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__request__registe__49C3F6B7");

            entity.HasOne(d => d.Req).WithMany()
                .HasForeignKey(d => d.ReqId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__request__req_id__4AB81AF0");
        });

        modelBuilder.Entity<Request1>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PK__Requests__18D3B90F692DD922");

            entity.ToTable("Requests");

            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.RequestDate)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("request_date");
            entity.Property(e => e.RequestDescription)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("request_description");
            entity.Property(e => e.RequestStatus)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("request_status");
            entity.Property(e => e.RequestType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("request_type");
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.HasKey(e => e.TransactionId).HasName("PK__Transact__85C600AFB9931786");

            entity.Property(e => e.TransactionId).HasColumnName("transaction_id");
            entity.Property(e => e.SenderAccountNumber).HasColumnName("sender_account_number");
            entity.Property(e => e.TransactionAmount)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("transaction_amount");
            entity.Property(e => e.TransactionDate)
                .HasColumnType("date")
                .HasColumnName("transaction_date");
            entity.Property(e => e.TransactionPassword)
                .HasMaxLength(256)
                .IsUnicode(false)
                .HasColumnName("transaction_password");
            entity.Property(e => e.TransactionType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("transaction_type");
        });

        modelBuilder.Entity<TransactionForeign>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("transaction_foreign");

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.TransacId).HasColumnName("transac_id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__transacti__regis__34C8D9D1");

            entity.HasOne(d => d.Transac).WithMany()
                .HasForeignKey(d => d.TransacId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__transacti__trans__35BCFE0A");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.RegisteredId).HasColumnName("registered_id");
            entity.Property(e => e.UserRoleId).HasColumnName("User_Role_Id");

            entity.HasOne(d => d.Registered).WithMany()
                .HasForeignKey(d => d.RegisteredId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Users__registere__44FF419A");

            entity.HasOne(d => d.UserRole).WithMany()
                .HasForeignKey(d => d.UserRoleId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("FK__Users__User_Role__45F365D3");
        });

        modelBuilder.Entity<UserRole>(entity =>
        {
            entity.HasKey(e => e.UserRoleId).HasName("PK__UserRole__134E488C650E797A");

            entity.ToTable("UserRole");

            entity.Property(e => e.UserRoleId).HasColumnName("User_Role_Id");
            entity.Property(e => e.UserRole1)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("User_Role");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
