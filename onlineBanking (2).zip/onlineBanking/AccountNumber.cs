﻿using System;
using System.Collections.Generic;

namespace onlineBanking;

public partial class AccountNumber
{
    public long? AccountNumber1 { get; set; }

    public int? RegisteredId { get; set; }

    public virtual Registered? Registered { get; set; }
}
